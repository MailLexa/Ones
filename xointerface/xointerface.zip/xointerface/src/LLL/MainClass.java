package LLL;

import LLL.game.Game;

public class MainClass {
    public static void main (String[] args){
        Game gameInstance = new Game();
        gameInstance.initGame();

    }


}
